﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnableAllInList : MonoBehaviour
{
    public GameObject[] items;

    void Update()
    {
        if (PacDot.foodConsumptionCount == 173)
        {
            for (int item = 0; item < items.Length; item++)
            {
                items[item].SetActive(true);
                items[item].GetComponent<Renderer>().enabled = true;
                items[item].GetComponent<BoxCollider2D>().enabled = true;
            }
        }
    }
}
