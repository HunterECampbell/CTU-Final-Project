﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PacDot : MonoBehaviour
{
    public static int foodConsumptionCount = 0;
    private Color newColor;

    void OnTriggerEnter2D(Collider2D sprite) {
        if (sprite.name == "Pacman")
        {
            gameObject.SetActive(false);
            UpdateScoreText.scoreValue += 5;
            foodConsumptionCount += 1;
        }

        if (foodConsumptionCount == 173)
        {
            UpdateLevel.levelCount++;
            if (UpdateLevel.levelCount <= 10)
            {
                Ghost.speed += 0.01f;
            }
            else if (UpdateLevel.levelCount > 10 & UpdateLevel.levelCount % 10 == 0)
            {
                Ghost.speed += 0.05f;
            }

            UpdateScoreText.scoreValue += (1000 * (UpdateLevel.levelCount - 1));
            gameObject.SetActive(true);
            UpdateLevel.background.GetComponent<Camera>().backgroundColor = new Color(Random.Range(0F,1F), Random.Range(0, 1F), Random.Range(0, 1F));
        }
    }
}
