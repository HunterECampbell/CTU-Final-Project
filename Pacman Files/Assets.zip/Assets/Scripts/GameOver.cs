﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour
{
    public static bool gameOver = false;
    public GameObject gameOverMenuUI;

    void Start()
    {
        gameOverMenuUI.SetActive(false);
    }

    void Update()
    {
        if (gameOver)
        {
            showMenu();
        }
    }

    void showMenu()
    {
        gameOverMenuUI.SetActive(true);
        Time.timeScale = 0.0f;
    }
}
