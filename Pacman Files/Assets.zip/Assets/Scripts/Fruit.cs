﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour
{
    private static Coroutine lastRoutine = null;
    public GameObject[] TheGhosts;
    public Sprite[] PowerUpSprite;

    void Start()
    {
      TheGhosts = GameObject.FindGameObjectsWithTag("Ghost");
    }

    void Update()
    {
        if (PacDot.foodConsumptionCount == 173)
        {
            gameObject.GetComponent<Renderer>().enabled = true;
            gameObject.GetComponent<BoxCollider2D>().enabled = true;
        }
    }

    void OnTriggerEnter2D(Collider2D sprite)
    {
        if (sprite.name == "Pacman")
            gameObject.GetComponent<Renderer>().enabled = false;
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
            UpdateScoreText.scoreValue += 50;
            Ghost.powerUp = true;
            Ghost.flashing = false;
            if (lastRoutine != null)
                StopCoroutine(lastRoutine);
            lastRoutine = StartCoroutine(PowerUp());
    }

    void FlashGhostFadingPowerUpSprite()
    {
      for (int ghost = 0; ghost < TheGhosts.Length; ghost++) {
        TheGhosts[ghost].GetComponent<SpriteRenderer>().sprite = PowerUpSprite[0];
      }
    }

    void FlashGhostPowerUpSprite()
    {
      for (int ghost = 0; ghost < TheGhosts.Length; ghost++) {
        TheGhosts[ghost].GetComponent<SpriteRenderer>().sprite = PowerUpSprite[1];
      }
    }

    IEnumerator PowerUp()
    {
        // Stuff to turn on for the power-up
        Pacman.speed = 0.35f;
        Ghost.speed = 0.05f;

        // Start flashing ghosts
        yield return new WaitForSeconds(3.0f);
        Ghost.flashing = true;
        FlashGhostFadingPowerUpSprite();
        yield return new WaitForSeconds(0.4f);
        FlashGhostPowerUpSprite();
        yield return new WaitForSeconds(0.4f);
        FlashGhostFadingPowerUpSprite();
        yield return new WaitForSeconds(0.4f);
        FlashGhostPowerUpSprite();
        yield return new WaitForSeconds(0.3f);
        FlashGhostFadingPowerUpSprite();
        yield return new WaitForSeconds(0.3f);
        FlashGhostPowerUpSprite();
        yield return new WaitForSeconds(0.2f);

        // Stuff to turn off after power-up time is over
        Pacman.speed = 0.2f;
        Ghost.speed = Ghost.lastSpeed;
        Ghost.powerUp = false;
        Ghost.flashing = false;
    }
}
