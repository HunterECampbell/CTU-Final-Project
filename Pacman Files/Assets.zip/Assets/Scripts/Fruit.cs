﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour
{
    private static Coroutine lastRoutine = null;

    void Update()
    {
        if (PacDot.foodConsumptionCount == 173)
        {
            gameObject.GetComponent<Renderer>().enabled = true;
            gameObject.GetComponent<BoxCollider2D>().enabled = true;
        }
    }

    void OnTriggerEnter2D(Collider2D sprite)
    {
        if (sprite.name == "Pacman")
            gameObject.GetComponent<Renderer>().enabled = false;
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
            UpdateScoreText.scoreValue += 50;
            Ghost.powerUp = true;
            if (lastRoutine != null)
                StopCoroutine(lastRoutine);
            lastRoutine = StartCoroutine(PowerUp());
    }

    IEnumerator PowerUp()
    {
        // Stuff to turn on for the power-up
        Pacman.speed = 0.35f;
        Ghost.speed = 0.05f;

        yield return new WaitForSeconds(5.0f);

        // Stuff to turn off after power-up time is over
        Pacman.speed = 0.2f;
        Ghost.speed = Ghost.lastSpeed;
        Ghost.powerUp = false;
    }
}
