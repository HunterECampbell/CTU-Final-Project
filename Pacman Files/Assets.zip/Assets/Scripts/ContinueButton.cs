﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine;
using UnityEngine.UI;

public class ContinueButton : MonoBehaviour
{
    private Button continueButton;
    public GameObject pauseMenuUI;

    void Start()
    {
        continueButton = GetComponent<Button>();
        continueButton.onClick.AddListener(ContinueGame);
    }

    private void ContinueGame()
    {
        pauseMenuUI.SetActive(false);
        if (!Ghost.pacmanDead) {
            Time.timeScale = 1.0f;
        }
        PauseGame.isPaused = false;
    }
}
