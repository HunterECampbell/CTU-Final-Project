﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pacman : MonoBehaviour
{
    public static float speed = 0.2f;
    public static Vector2 destination = Vector2.zero;
    private Vector3 leftPosition;
    private Vector3 rightPosition;
    public static AudioSource moveSound;
    public static Vector3 originalPosition;

    void Start()
    {
        destination = transform.position;
        leftPosition = new Vector3(-19.0f, 1.4f, 0.0f);
        rightPosition = new Vector3(19.0f, 1.4f, 0.0f);
        moveSound = GetComponent<AudioSource>();
        originalPosition = transform.position;
    }

    void FixedUpdate()
    {
        // Calculate movement
        Vector2 pos = Vector2.MoveTowards(transform.position, destination, speed);
        GetComponent<Rigidbody2D>().MovePosition(pos);

        // Check for keyboard inputs
        if ((Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) && validDirection(Vector2.up))
            destination = (Vector2)transform.position + Vector2.up;
        if ((Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) && validDirection(Vector2.up))
            destination = (Vector2)transform.position - Vector2.up;
        if ((Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) && validDirection(Vector2.right))
            destination = (Vector2)transform.position + Vector2.right;
        if ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) && validDirection(Vector2.right))
            destination = (Vector2)transform.position - Vector2.right;

        // Animation Calculations
        Vector2 direction = destination - (Vector2)transform.position;
        GetComponent<Animator>().SetFloat("Direction_X", direction.x);
        GetComponent<Animator>().SetFloat("Direction_Y", direction.y);

    }

    // Checks for walls by casting lines
    bool validDirection(Vector2 dir)
    {
        Vector2 pos = transform.position;
        RaycastHit2D hit = Physics2D.Linecast(pos + dir, pos);
        if (!moveSound.isPlaying & !Ghost.pacmanDead)
            moveSound.Play();
        return (hit.collider == GetComponent<Collider2D>());
    }    
    
    void OnTriggerEnter2D(Collider2D sprite) {
        if (sprite.name == "LeftPortal")
            transform.position = rightPosition;
            
        if (sprite.name == "RightPortal")
            transform.position = leftPosition;
    }
}