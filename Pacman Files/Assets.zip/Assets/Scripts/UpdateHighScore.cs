﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateHighScore : MonoBehaviour
{
    public static int highScoreValue = 0;
    Text highScore;
    public static GameObject theScore;
    public static GameObject theGameOverHighScore;
    public static bool tryToSetNewHighScore = false;

    void Start()
    {
        highScore = GetComponent<Text>();
        theScore = GameObject.Find("Score Background");
        theGameOverHighScore = GameObject.Find("High Score Background");
    }

    void Update()
    {
        SetHighScore();
        tryToSetNewHighScore = false;
    }

    void SetHighScore()
    {
        if (tryToSetNewHighScore)
        {
            if (UpdateScoreText.scoreValue > highScoreValue & UpdateLives.pacmanLivesCount == 0)
            {
                PlayerPrefs.SetInt("HighScore", highScoreValue);
                theScore.SetActive(false);
                theGameOverHighScore.SetActive(true);
                highScoreValue = UpdateScoreText.scoreValue;
                PlayerPrefs.SetInt("HighScore", highScoreValue);
                highScore.text = "New High Score!\n" + PlayerPrefs.GetInt("HighScore", 0);
            }
            else
            {
                theScore.SetActive(true);
                theGameOverHighScore.SetActive(false);
            }
        }
    }
}
