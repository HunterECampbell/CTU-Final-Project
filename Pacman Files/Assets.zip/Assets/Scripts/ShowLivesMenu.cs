﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowLivesMenu : MonoBehaviour
{
    public static bool updatingLives = false;
    public GameObject livesMenu;

    void Start()
    {
        livesMenu.SetActive(false);
    }

    void Update()
    {
        if (updatingLives & !GameOver.gameOver)
        {
            showMenu();
        }
        else
        {
            livesMenu.SetActive(false);
        }
    }

    void showMenu()
    {
        livesMenu.SetActive(true);
    }
}
