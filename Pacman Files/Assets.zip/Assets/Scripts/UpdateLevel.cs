﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateLevel : MonoBehaviour
{
    Text level;
    public static int levelCount = 1;
    public static GameObject background;

    void Start()
    {
        level = GetComponent<Text>();
        background = GameObject.Find("Main Camera");
    }

    void Update()
    {
        level.text = "Level: " + levelCount;
    }
}
