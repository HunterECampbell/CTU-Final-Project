﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpdateLives : MonoBehaviour
{
    Text pacmanLives;
    public static int pacmanLivesCount = 3;

    void Start()
    {
        pacmanLives = GetComponent<Text>();
    }

    void Update()
    {
        pacmanLives.text = "Lives: " + pacmanLivesCount;
    }
}
