﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portals : MonoBehaviour
{
    /*void OnTriggerEnter2D(Collider2D sprite) {
        if (sprite.name == "PacMan" & gameObject.name == "LeftPortal")
            sprite.transform.position = (19.0, 1.4, 0.0);
            
        if (sprite.name == "PacMan" & gameObject.name == "RightPortal")
            sprite.transform.position = (-19.0, 1.4, 0.0);
    }*/
}
