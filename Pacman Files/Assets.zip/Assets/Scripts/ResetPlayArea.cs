﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetPlayArea : MonoBehaviour
{
    public static void totalReset()
    {
        Ghost.powerUp = false;
        Ghost.pacmanDead = false;
        Ghost.speed = 0.2f;

        PacDot.foodConsumptionCount = 0;

        Pacman.speed = 0.2f;

        PauseGame.isPaused = false;
        PauseGame.allowPausing = true;

        UpdateScoreText.scoreValue = 0;

        UpdateLives.pacmanLivesCount = 3;

        UpdateLevel.levelCount = 1;

        GameOver.gameOver = false;

        ShowLivesMenu.updatingLives = false;

        ShowNewLevelMenu.startingNewLevel = false;

    }
}
