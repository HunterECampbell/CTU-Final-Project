﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowNewLevelMenu : MonoBehaviour
{
    public static bool startingNewLevel = false;
    public GameObject newLevelMenu;

    void Start()
    {
        newLevelMenu.SetActive(false);
    }

    void Update()
    {
        if (startingNewLevel)
        {
            showMenu();
        }
        else
        {
            newLevelMenu.SetActive(false);
        }
    }

    void showMenu()
    {
        newLevelMenu.SetActive(true);
    }
}
