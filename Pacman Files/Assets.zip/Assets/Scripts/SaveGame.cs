﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public static class SaveGame
{
    public static List<UpdateScoreText> savedHighScores = new List<UpdateScoreText>();

    public static void Save()
    {
        savedHighScores.Add(UpdateScoreText.current);
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/savedHighScores.gd");
        bf.Serialize(file, SaveGame.savedHighScores);
        file.Close();
    }

    public static void Load()
    {
        if (File.Exists(Application.persistentDataPath + "/savedHighScores.gd"))
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/savedHighScores.gd", FileMode.Open);
            SaveGame.savedHighScores = (List<UpdateScoreText>)bf.Deserialize(file);
            file.Close();
        }
    }
}
