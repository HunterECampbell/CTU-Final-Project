﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ghost : MonoBehaviour
{
    public static float speed = 0.2f;
    public static float lastSpeed;
    public static bool powerUp = false;
    public Transform[] waypoints;
    private int currentWaypoint = 0;
    public static Sprite originalSprite;
    public Sprite[] powerUpSprite;
    private Vector3 originalPosition;
    private AudioSource pacmanDeathSound;
    public static bool pacmanDead = false;
    public GameObject thePacman;

    void Start()
    {
        originalSprite = gameObject.GetComponent<SpriteRenderer>().sprite;
        originalPosition = transform.position;
        transform.position = waypoints[currentWaypoint].transform.position;
        pacmanDeathSound = GetComponent<AudioSource>();
        thePacman = GameObject.Find("Pacman");
        StartCoroutine(waitOnLevelLoad());
    }

    void FixedUpdate()
    {
        Move();

        if (!powerUp & !pacmanDead)
        {
            lastSpeed = speed;
        }

        // Animation
        Vector2 direction = waypoints[currentWaypoint].position - transform.position;
        GetComponent<Animator>().SetFloat("Direction_X", direction.x);
        GetComponent<Animator>().SetFloat("Direction_Y", direction.y);

        if (powerUp)
        {
            gameObject.GetComponent<Animator>().enabled = false;
            gameObject.GetComponent<SpriteRenderer>().sprite = powerUpSprite[0];
        }
        else
        {
            gameObject.GetComponent<Animator>().enabled = true;
            gameObject.GetComponent<SpriteRenderer>().sprite = originalSprite;
        }

        if (pacmanDead)
        {
            StartCoroutine(ResetSprites());
        }

        if (PacDot.foodConsumptionCount == 173)
        {
            pacmanDead = true;
            StartCoroutine(ResetSpritesForNewLevel());
            PacDot.foodConsumptionCount = 0;
        }
    }

    void Move()
    {
        gameObject.GetComponent<BoxCollider2D>().enabled = false;

        transform.position = Vector2.MoveTowards(
            transform.position,
            waypoints[currentWaypoint].transform.position,
            speed
        );
        
        if (transform.position == waypoints[currentWaypoint].transform.position)
            currentWaypoint += 1;
            
        if (currentWaypoint == waypoints.Length)
            currentWaypoint = 1;

        if (currentWaypoint > 0)
            gameObject.GetComponent<BoxCollider2D>().enabled = true;
    }

    // Kill Pacman if touch ghost and not in power-up mode
    void OnTriggerEnter2D(Collider2D sprite)
    {
        if (sprite.name == "Pacman" & !powerUp)
        {
            sprite.GetComponent<Renderer>().enabled = false;
            sprite.GetComponent<Animator>().enabled = false;
            sprite.GetComponent<CircleCollider2D>().enabled = false;
            pacmanDeathSound.Play();
            UpdateLives.pacmanLivesCount--;
            if (UpdateLives.pacmanLivesCount == 0)
            {
                UpdateHighScore.tryToSetNewHighScore = true;
                GameOver.gameOver = true;
            }
            pacmanDead = true;
        }
        else if (sprite.name == "Pacman" & powerUp)
        {
            UpdateScoreText.scoreValue += 150;
            StartCoroutine(ResetGhost());
        }
    }

    IEnumerator waitOnLevelLoad()
    {
        transform.position = originalPosition;
        currentWaypoint = -1;
        speed = 0f;
        Pacman.speed = 0f;

        yield return new WaitForSeconds(0.5f);

        speed = 0.2f;
        currentWaypoint = 0;
        Pacman.speed = 0.2f;
    }

    IEnumerator ResetGhost()
    {
        currentWaypoint = -1;
        GetComponent<Renderer>().enabled = false;
        GetComponent<Animator>().enabled = false;

        yield return new WaitForSeconds(3.0f);
        
        currentWaypoint = 0;
        GetComponent<Renderer>().enabled = true;
        GetComponent<Animator>().enabled = true;
    }

    IEnumerator ResetSprites()
    {
        transform.position = originalPosition;
        currentWaypoint = -1;
        speed = 0f;
        powerUp = false;
        GetComponent<Renderer>().enabled = false;
        GetComponent<Animator>().enabled = false;
        Pacman.speed = 0f;
        thePacman.transform.position = Pacman.originalPosition;
        transform.position = originalPosition;
        thePacman.GetComponent<Renderer>().enabled = false;
        thePacman.GetComponent<Animator>().enabled = false;
        thePacman.GetComponent<CircleCollider2D>().enabled = false;
        ShowLivesMenu.updatingLives = true;
        PauseGame.allowPausing = false;

        yield return new WaitForSeconds(1.5f);

        currentWaypoint = 0;
        speed = lastSpeed;
        GetComponent<Renderer>().enabled = true;
        GetComponent<Animator>().enabled = true;
        Pacman.speed = 0.2f;
        Pacman.destination = Pacman.originalPosition;
        thePacman.GetComponent<Renderer>().enabled = true;
        thePacman.GetComponent<Animator>().enabled = true;
        thePacman.GetComponent<CircleCollider2D>().enabled = true;
        pacmanDead = false;
        ShowLivesMenu.updatingLives = false;
        PauseGame.allowPausing = true;
    }

    IEnumerator ResetSpritesForNewLevel()
    {
        transform.position = originalPosition;
        currentWaypoint = -1;
        speed = 0f;
        powerUp = false;
        GetComponent<Renderer>().enabled = false;
        GetComponent<Animator>().enabled = false;
        Pacman.speed = 0f;
        thePacman.transform.position = Pacman.originalPosition;
        transform.position = originalPosition;
        thePacman.GetComponent<Renderer>().enabled = false;
        thePacman.GetComponent<Animator>().enabled = false;
        thePacman.GetComponent<CircleCollider2D>().enabled = false;
        ShowNewLevelMenu.startingNewLevel = true;
        PauseGame.allowPausing = false;

        yield return new WaitForSeconds(1.5f);

        currentWaypoint = 0;
        speed = lastSpeed;
        GetComponent<Renderer>().enabled = true;
        GetComponent<Animator>().enabled = true;
        Pacman.speed = 0.2f;
        Pacman.destination = Pacman.originalPosition;
        thePacman.GetComponent<Renderer>().enabled = true;
        thePacman.GetComponent<Animator>().enabled = true;
        thePacman.GetComponent<CircleCollider2D>().enabled = true;
        pacmanDead = false;
        ShowNewLevelMenu.startingNewLevel = false;
        PauseGame.allowPausing = true;
    }
}
