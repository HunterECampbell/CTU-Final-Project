﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NavigateToMainMenu : MonoBehaviour
{
    private Button mainMenuButton;
    public GameObject menuUI;

    void Start()
    {
        mainMenuButton = GetComponent<Button>();
        mainMenuButton.onClick.AddListener(MainMenu);
    }

    private void MainMenu()
    {
        SceneManager.LoadScene("HomePage");
        menuUI.SetActive(false);
        Time.timeScale = 1.0f;
        ResetPlayArea.totalReset();
        UpdateHighScore.theScore.SetActive(false);
    }
}
